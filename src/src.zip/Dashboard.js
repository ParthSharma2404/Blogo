import { useEffect, useState } from "react";
import Register from "./Registeration";
import { useAuth } from "./AuthContext.js";
import { deleteDoc, doc } from "firebase/firestore";
import { db } from "./firebase";
import {
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
} from "firebase/firestore";
// import ProtectedRoute from "./ProtectedRoute.js";
function Dashboard() {
  // const name = localStorage.getItem("username");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [blogs, setBlogs] = useState([]);
  const { username } = useAuth();
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title || !content) return alert("All fields are required");
    try {
      await addDoc(collection(db, "blogs"), {
        title,
        content,
        author: username,
        timestamp: new Date(),
      });
      setTitle("");
      setContent("");
    } catch (err) {
      alert("Error adding blog: " + err.message);
    }
  };

  // ✅ Delete blog post
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this blog?");
    if (!confirmDelete) return;

    try {
      await deleteDoc(doc(db, "blogs", id));
    } catch (err) {
      alert("Error deleting blog: " + err.message);
    }
  };
    useEffect(() => {
    const q = query(collection(db, "blogs"), orderBy("timestamp", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setBlogs(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsubscribe();
  }, []);
  return (
    <div className="my-20 mx-10 p-10 text-2xl font-semibold">
      <div className="text-3xl font-medium">Welcome {username} to your Dashboard!</div>
      <p className="text-2xl font-thin mt-4">
        Here you can write and manage your blogs.
      </p>
      <div className="h-1 bg-gray-400 my-10"></div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={title}
          placeholder="Title"
          className="text-3xl rounded-xl pl-2 py-2  mt-4 mb-10 border dark:text-black focus:outline focus:outline-green-400"
          onChange={(e) => setTitle(e.target.value)}
        />{" "}
        <br />
        <textarea
          type="text"
          value={content}
          placeholder="Content"
          className="w-full text-2xl p-2 rounded-xl border mb-4 dark:text-green-400 focus:outline focus:outline-green-400"
          required
          onChange={(e) => setContent(e.target.value)}
        />{" "}
        <br />
        <button
          type="submit"
          className="mt-4 px-4 py-2 bg-green-400 text-white rounded hover:bg-green-600"
        >
          Publish Blog
        </button>
      </form>
      {/* Blog List */}
      <div className="max-w-3xl mx-auto text-left mt-10">
        <h2 className="text-3xl mb-6 text-center border py-5 border-2 border-green-400 rounded-xl">Your Blogs</h2>
        {blogs.length === 0 ? (
          <p className="text-3xl font-thin">No blogs yet . . . .</p>
        ) : (
          blogs.map((blog) => (
            <div
              key={blog.id}
              className="grid mb-6 pb-4 border rounded shadow-md bg-white bg-slate-100 dark:bg-[#2a3a43]"
            >
              <h3 className="text-2xl mt-1  mx-1 px-2 py-1 font-bold font-mono rounded-sm  bg-white dark:text-black ">{blog.title}</h3>
              <p className="text-base mt-2 px-3 whitespace-pre-wrap  font-mono">{blog.content}</p>
              {/* <p className="text-sm text-right mt-4 text-gray-600">– {blog.author}</p> */}

              {/* ✅ Show Delete Button if author matches */}
              {blog.author === username && (
                <div className="text-right mt-2">
                  <button
                    onClick={() => handleDelete(blog.id)}
                    className="mr-3 px-6 py-1 bg-red-500 text-white text-sm rounded hover:bg-red-600"
                  >
                    Delete
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
export default Dashboard;
