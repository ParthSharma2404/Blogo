import { useState } from "react";
import { auth } from "./firebase";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "./AuthContext";

function Registeration() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { setUsername } = useAuth();
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      localStorage.setItem("username", name);
      setUsername(name);
      navigate("/dashboard");
    } catch (error) {
      alert("Registration failed: " + error.message);
    }
  };

  return (
    <div className="min-h-screen content-center">
      <h1 className="font-extrabold text-5xl text-center">Register</h1>
      <form className="text-center mt-10 mb-2" onSubmit={submit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="outline outline-2 text-2xl rounded-xl pl-3 py-2 mb-5 focus:outline-green-400 dark:text-black"
        /><br/>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="outline outline-2 text-2xl rounded-xl pl-3 py-2 mb-5 focus:outline-green-400 dark:text-black"
        /><br/>
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="outline outline-2 text-2xl rounded-xl pl-3 py-2 mb-5 focus:outline-green-400 dark:text-black"
        /><br/>
        <input
          type="submit"
          className="font-medium text-2xl outline outline-2 px-4 py-2 rounded-xl hover:bg-green-400 hover:text-white hover:duration-300"
        />
      </form>
      <div className="text-center">
        <Link to="/login" className="text-green-400 font-semibold text-xl">Already have an account?</Link>
      </div>
    </div>
  );
}

export default Registeration;
