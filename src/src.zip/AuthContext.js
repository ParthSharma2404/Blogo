import { createContext, useContext, useEffect, useState } from "react";
import { auth } from "./firebase.js";
import { onAuthStateChanged } from "firebase/auth";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [username, setUsername] = useState("");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const storedName = localStorage.getItem("username");
        if (storedName) {
          setUsername(storedName);
        }
      } else {
        setUsername("");
      }
    });
    return () => unsubscribe();
  }, []);

  const value = {
    user,
    username,
    setUsername,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
