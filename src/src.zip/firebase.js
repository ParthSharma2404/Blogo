// firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBBIPG4n7IC3yvFvRGtilW2o0bAMpDs81w",
  authDomain: "login-details-4d2d3.firebaseapp.com",
  projectId: "login-details-4d2d3",
  storageBucket: "login-details-4d2d3.appspot.com",
  messagingSenderId: "15626801328",
  appId: "1:15626801328:web:dbf52e445783a42c61eb75",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth,db };
